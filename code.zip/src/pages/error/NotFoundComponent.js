import React from "react";

const NotFoundComponent = () => {
    return (
        <>404 Page Not Found</>
    )
}

export default NotFoundComponent;