import React from "react";

const UnAuthComponent = () => {
    return (
        <>UnAuthorized User</>
    )
}

export default UnAuthComponent;