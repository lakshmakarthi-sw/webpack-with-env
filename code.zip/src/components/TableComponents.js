import React from "react";

const TableComponent = () => {

    console.log("This is TableComponent");
    
    return (
        <div>
            Table components
        </div>
    );
}

export default TableComponent; 